<style type="text/css">
		*
		{
			margin: 0px;
			padding: 0px;
		}

		body
		{
			background:#5b7793;
			background-repeat: no-repeat;
			background-size: cover;
		}
		ul li
		{
			list-style: none;
		}
		a
		{
			text-decoration: none;
		}
		
		.logo 
		{
			float: left;
			color: #66ccff;
			padding: 15px 5px;
			font-size: 10px;
		}
		.service
		{
			display: flex;
			justify-content: center;
		}
		.service-item
		{
			width: 200px;
			border: 1px solid black;
			border-radius: 10px;
			transition: .3s;
		}
		.service-item:hover
		{
			box-shadow: 0px 0px 25px #666bffe0;
		}
		.coto
		{
			height: 180px;
			width: 200px;
			border: 0px solid #ddd;

		}
		.coto img
		{
			height: 100%;
			width: 100%;
			border-radius: 10px;
		}
		.ser-con
		{
			text-align: center;
			padding: 3px;
			background: white;
			border-radius: 10px;
		}
		.dm
		{
			margin: 0 10px;
		}
		.service-part
		{
			padding-top: 150px;
			border-radius: 10px;
		}


		.footer-part
	{
		background: #17171778;
		height: 178px;
		margin-top: 380px;
	}
	.footer-top
	{
		
		height: 100px;
	}
	.footer-top p
	{
	 	float: right;
	 	margin-top: 10px;
	 	font-size: 12px;
	 	color: white;

	}
	
	.footer-bottom p
	{
		color:white;
	}
	.common
	{
		padding: 0 100px;
	}
	

	</style>