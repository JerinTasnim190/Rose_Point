<?php 
  include 'dash_style.php';

 ?>


<div style="clear:both">
  <br/>
  <h3>order details </h3>
  <div class="table_responsive">
    <table class="table table-bordered">
      <tr>
        <th width="40%">Item name</th>
        <th width="10%">Item price</th>
        <th width="20%">Item total</th>
        <th width="5%">Action</th>
      </tr>
    </table>
  </div>
</div>