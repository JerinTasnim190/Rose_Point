
<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}

		ul li
		{
			list-style: none;
		}
		a
		{
			text-decoration: none;
		}

		div#jj
		{
			margin: auto;
			margin-top: 10%;
			width:320px; 
			border:1px solid #89bae0c9;
			padding: 10px;
			background: #89bae0c9;
			border-radius: 10px;
			height: 500px;
		}
		 input
		{
			margin-bottom: 11px;
			width: 99%;
			padding-top: 6px;
			padding-bottom: 6px;

		}
		.radio input
		{
			margin:0px;
		}

		.sUp
		{
			background: #89bae038;
			margin-bottom: 10px;
			text-align: center;
			
		}
		.link
		{
			align-content: center;
			color: blue;
		}
		
		#ss input
		{
			margin-top: 20px;
			font-size: 16px;
			background:#89bae000;
			border: 2px solid #000;
			width:158px;
			font-family: arial black;
			margin-left: 80px;

		}
		.link
		{
			color: #000;
			margin-left: 20px;
			margin-top: 10px;
		}
		
	</style>
	