<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home/Rose Point</title>
	<link rel="stylesheet"  href="style/index.css">

</head>

<body>

	<header class="header-part">
		<div class="header-overlay">
			<div class="common">
				<nav class="main-menu">
					<a href=" index.php">
					<div class="logo">
						<h1>ROSE POINT</h1>
					</div>
					</a>
					<ul>
						<li><a href="login.php" class="button1"><b>Login </b></a></li>
						<li><a href="signup.php" class="button2"><b> Registration</b></a></li>
						<li><a href="" class=" button3"><b> Logout</b></a></li>
					</ul>
				</nav>

				<div class="content text-center">
					<h2> Deliver within 24 hours </h2> <br> <h3 style="color:white;">We are open for you</h3> <br>
					<a href="flower_shop.php"><b>SHOP</b></a>
				</div>
			</div>
		</div>
	</header>
	<section class="midm">  
		<div class="about-content">
			<div class="about-content-left">
					<h4 style="color:#4a7083;">Team Alpha will be represent rose point. Rose point like a family where every customer is not a customer they are family and rose point always here to give the best support to our family. We are always deliver our product within 24 hours. Our vision is, we will try our best to give the best service. This totally new concept in Bangladesh. Further we do this kind of website did not introduce them. 
Initially this is only in Dhaka city. As quick as possible we will introduce us at Chittogong and Bogura.  
</h4>
				</div>
				<section id="ssj">
				<div >
			<div style="text-align: center; margin-bottom: -60px; font-size: 25px; margin-top: 134px;">
					<h1> Customer service</h1>
				</div>
				<div class="about-content-right">
					<a href="profile.php">
						<div class="doctor">
						<div class="doctor-item nd">
							<div class="dt-img">
								<img src="style/picture/johirul.jpeg" alt="D.r..">
							</div>
							<div class="ser-con text-center">
								<h3>JAHIRUL ISLAM</h3>
								<p> CEO of rose point</p>
							</div>
						</div>

						<div class="doctor-item nd">
							<div class="dt-img">
								<img src="style/picture/shakil.jpg" alt="D.r...">
							</div>
							<div class="ser-con text-center">
								<h3>KH. SHAKIL</h3>
								<p>CO FOUNDER of rose point</p>
							</div>
						</div>
						<div class="doctor-item nd">
							<div class="dt-img">
								<img src="style/picture/jerin.jpeg" alt="D.r...">
							</div>
							<div class="ser-con text-center">
								<h3>JERIN TASNIM</h3>
								<p>MD of rose point</p>
							</div>
						</div>
					</div>
					</a>
					
				</div>
				</section>			
			</div>
		</div>
		
				
	</section>

	<footer class="footer-part">
		<section id="contact"></section>
		<div class="footer-top">
			<div class="cont">Contacts:</div>
				<ul>
					<li><a href="https://www.facebook.com/jerintasnim.niha.1"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Facebook_icon_2013.svg/2000px-Facebook_icon_2013.svg.png" width="30px" height="100%" alt=""></li>
					<li><a href=" "><img src="https://cdn2.iconfinder.com/data/icons/minimalism/512/twitter.png" width="30px" height="100%" alt=""></li>
					<li><a href=" "><img src="https://cdn0.iconfinder.com/data/icons/social-media-circle-6/1024/instagram-512.png" width="30px" height="100%" alt=""></li>
					<li><a href=" "><img src="https://cdn1.iconfinder.com/data/icons/logotypes/32/square-linkedin-512.png" width="30px" height="100%" alt=""></li>
					
				</ul>
			</div>
			<div class="footer-bottom"><hr>
				<p>© 2021 ROSE POINT </p>
			</div>
		</div>
	</footer>
	
</body>
</html>