

<style>

	*
		{
			margin: 0px;
			padding: 0px;
		}

		body
		{
			background: #5b7793;
			float: center;

		}
		ul li
		{
			list-style: none;
		}
		a
		{
			text-decoration: none;
		}
		.service
		{
			display: flex;
			justify-content: center;
			
		}
		.service-item
		{
			width: 150px;
			border: 1px solid black;
			border-radius: 10px;
			transition: .3s;
		}
		.service-item:hover
		{
			box-shadow: 0px 0px 25px #66ccff;
		}
		.coto
		{
			height: 120px;
			width: 150px;
			border: 0px solid #ddd;

		}
		.coto img
		{
			height: 100%;
			width: 100%;

			
		}
		.ser-con
		{
			text-align: center;
			padding: 3px;
			background: white;

			
		}
		.dm
		{
			margin: 0 10px;

		}
		.service-part
		{
			padding-top: 50px;
			border-radius: 10px;

		}
		.btn-theme
		{
			background: green;
			color: white;
			font-size: 21px;
		}
		.common
		{
			padding: 0 100px;

		}
		.search
		{
			width: 20%;
			height: 25px;
			border-color: #66ccff;
		}
		.btn-primary
		{
			background: green;
			color: white;
			width: 137px;
		}
		.btn1
		{
			background:black;
			color: white;
			width: 137px;
			margin-bottom: 5px;
			margin-top: 5px;
		}
</style>
