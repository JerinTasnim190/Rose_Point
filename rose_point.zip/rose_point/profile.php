<?php 
include 'hearder.php';
 ?>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 <div class="card w-75">
  <div class="card-body">
    <h5 class="card-title"> ASSALAMUALAIKUM </h5>
    <p class="card-text">I am available right now. You can call me or chat with me for any queries. </p>
    <a href="#" class="btn btn-primary">Live Chat</a>
     <a href="#" class="btn btn-primary">Call</a>
  </div>
</div>